<?php

namespace App\Http\Controllers;

use App\Helpers\Post;
use Illuminate\Routing\ResponseFactory;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\Artisan;
use PHPUnit\Framework\ExpectationFailedException;
use Symfony\Component\HttpKernel\Exception\HttpException;


class ElectionController extends Controller
{

    public function list(Request $request)
    {

     
	$url = "masterapache/cloud/public/api/master";
	
        $result = Post::send($url, ["query" => "SELECT * FROM tb_kandidat ORDER BY nama ASC", "token"=> $request->json('token')]);

 $result2 = Post::send($url, ["query" => "SELECT * FROM tb_polling", "token"=> $request->json('token')]);


        return response()->json(["candidateList" => $result, "allVote" => $result2], 200);


    }


 public function vote(Request $request)
    {

	$url = "masterapache/cloud/public/api/master/vote";


        $result = Post::send($url, $request->post());

       return response()->json($result, 200);


    }



}
